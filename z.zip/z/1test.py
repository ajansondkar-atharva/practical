def dfs(v,g,n):
    if (n not in v) and not v.add(n):
        print(n,end=" ")
        [dfs(v,g,x) for x in g[n]]

def bfs(v,g,n):
    q = [n]
    [v.add(n)]
    while q:
        s = q.pop(0)
        print(s,end=" ")
        [q.append(x) for x in g[s] if x not in v and not v.add(x)]

def main():
    g = {i: [int(input(f"Enter edge {j} for node {i} : ")) for j in range(int(input(f"Enter number of edges for node {i} : ")))] for i in range (1,int(input("Enter number of nodes : ")) + 1)}
    print("DFS")
    dfs(set(),g,1)
    print("\nBFS")
    bfs(set(),g,1)
    print()

if __name__ == "__main__":
    main()