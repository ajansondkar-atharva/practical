graph = [
    [0,1,1,1,0],
    [1,0,1,0,1],
    [1,1,0,1,0],
    [1,0,1,0,1],
    [0,1,1,1,0]
]

def greedy_coloring(graph):
    V = len(graph)
    result = [-1] * V
    result[0] = 0

    for u in range (1,V):
        available = [True] * V
        for i in range(V):
            if graph[u][i] == 1 and result[i] != -1:
                available[result[i]] = False
        result[u] = next(c for c in range(V) if available[c])

    print("Vertex \t Color")
    for u in range(V):
        print(f"{u} --> {result[u]}")
    print("Minimum colors required : ",len(set(result)))
def main():
    greedy_coloring(graph)

if __name__ == "__main__":
    main()
