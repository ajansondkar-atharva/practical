import queue as Q

dict_hn = {'A': 11, 'B': 169, 'C': 431, 'D': 567, 'E': 269}
dict_gn = {
    'A': {'B': 21, 'D': 12, 'E': 52},
    'B': {'A': 23, 'E': 45, 'C': 69},
    'C': {'B': 78, 'D': 87, 'E': 90},
    'D': {'A': 61, 'C': 11},
    'E': {'A': 44, 'B': 92, 'C': 59}
}

start, goal = 'B', 'C'

def get_fn(citystr):
    cities = citystr.split(", ")
    return dict_hn[cities[-1]] + sum(dict_gn[cities[i]][cities[i+1]] for i in range(len(cities)-1))

def expand(cityq):
    tot, citystr, thiscity = cityq.get()
    if thiscity == goal:
        print(f"The A* path with the total is: {citystr} :: {tot}")
        return
    for cty in dict_gn[thiscity]:
        cityq.put((get_fn(f"{citystr}, {cty}"), f"{citystr}, {cty}", cty))
    expand(cityq)

def main():
    cityq = Q.PriorityQueue()
    cityq.put((get_fn(start), start, start))
    expand(cityq)

main()
